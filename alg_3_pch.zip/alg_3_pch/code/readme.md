To run tests go to Algorithm.Tests and type in your terminal: dotnet test

Compiled with dotnet core 3.1
