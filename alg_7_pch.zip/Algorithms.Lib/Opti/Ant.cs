using System;

namespace Algorithms.Lib.Opti
{
    public class Ant : IOptiAlg
    {
        public double[] Opti(Func<double[], double> func)
        {
            throw new NotImplementedException();
        }
    }


}