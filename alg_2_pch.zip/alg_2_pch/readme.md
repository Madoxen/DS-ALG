This directory contains the following:
DataStructures.Lib - C# project containing simple datastructure library
DataStructures.Tests - C# project that is a test project for DataStructures.Lib
Docs - Algorithms flowcharts

Complied using dotnetcore3.1

To start go to DataStructures.Tests and type dotnet test in the terminal

